import numpy as np 
import matplotlib.pyplot as plt 

def funcion(x):
	y = np.sin(x)
	return y 

def inMontecarlo(N):
	
	val_min =  0
	val_max = np.pi

	x_ev = (val_max-val_min)*np.random.rand(N)+val_min	
		
	y_ev = funcion(x_ev) 	
	
	integral = np.mean(y_ev)*(val_max-val_min)
	
	return integral 

def integral20():
	suma = 0
	i = 0	
	while i < 20:
		suma+= inMontecarlo(10000)
		i+= 1
	
	return suma/20.0
	
resultado = integral20()

print "El valor de la integral es " , resultado
