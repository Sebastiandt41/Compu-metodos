import numpy as np 
import matplotlib.pyplot as plt 

potencial = np.genfromtxt("pot.dat")

Vr = potencial[:,0]
Vv = potencial[:,1]

h = Vr[1]-Vr[0]

#Calcula la derivada del potencial con el algoritmo de central difference
def CampoElec():
	
	Er = (Vv[2:]-Vv[:-2])/(2*h)
	
	return Er	

Er = -(CampoElec())
r = Vr[2:]

plt.scatter(r,Er)
plt.title("Campo electrico")
plt.xlabel("r")
plt.ylabel("E(r)")
plt.savefig("campo.pdf",format='pdf')


	
	 

